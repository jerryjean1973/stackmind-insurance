# Streamlit frontend
print('UI loaded')