# FastAPI backend
print('API running')